# Engineer review pack

This pack is the project's handoff: the Building Spec, the drawing set, the bar schedule, the
priced BOQ and the compliance audit with the Deviation Register.

**Everything in here is a candidate.** The drawing set, the BBS and the BOQ carry the
"candidate - not for construction" status, and the price list they were priced from is a
candidate card until a human marks it active. The manifest records the sha256 of every part, so
a part that arrived changed can be spotted.

- `manifest.json` - what is in the pack and each part's hash
- `spec.json` - the Building Spec (the source of truth)
- `drawings/` - the drawing set (PDF, the sheets' SVG, the set's manifest)
- `bbs/` - the bar schedule (xlsx + PDF)
- `boq/` - the bill of quantities (xlsx + PDF)
- `compliance/` - the compliance audit and the Deviation Register (markdown + the Bangla HTML)
